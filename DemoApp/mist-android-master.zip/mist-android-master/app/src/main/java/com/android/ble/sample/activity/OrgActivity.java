package com.android.ble.sample.activity;

import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.android.ble.sample.MainApplication;
import com.android.ble.sample.R;
import com.android.ble.sample.adapters.NotificationBeaconListAdapter;
import com.android.ble.sample.fragments.FloorplanFragment;
import com.android.ble.sample.fragments.OrgFragment;
import com.android.ble.sample.helper.PreferenceHelper;
import com.android.ble.sample.helper.Toaster;
import com.android.ble.sample.helper.Utility;
import com.android.ble.sample.listeners.AdapterListener;
import com.android.ble.sample.listeners.FragmentActivityListener;
import com.android.ble.sample.model.NotificationModel;
import com.android.ble.sample.model.PlaceNameModel;
import com.google.android.gms.maps.model.LatLng;
import com.mist.android.AppMode;
import com.mist.android.BatteryUsage;
import com.mist.android.MSTAsset;
import com.mist.android.MSTBeacon;
import com.mist.android.MSTCentralManagerListener;
import com.mist.android.MSTCentralManagerStatusCode;
import com.mist.android.MSTClient;
import com.mist.android.MSTMap;
import com.mist.android.MSTPoint;
import com.mist.android.MSTVirtualBeacon;
import com.mist.android.MSTZone;
import com.mist.android.MistIDGenerator;
import com.mist.android.SourceType;
import com.mist.android.model.AppModeParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by Entappiainc on 30-08-2016.
 */
public class OrgActivity extends FragmentActivity implements MSTCentralManagerListener, FragmentActivityListener, AdapterListener {

    private final static String sFragmentTag = "SIMPLE_FRAGMENT_TAG";
    private PlaceNameModel placeNameModel;

    private String hostUri;
    private String venueId;
    private String venuePassword;
    private String topic;
    private String name;
    private String environment = "Production";

    private MainApplication app;
    private boolean isAppInBackground = false;

    public MSTMap mstMap = null;
    public MSTPoint mstPoint = null;
    public MSTVirtualBeacon mstVirtualBeacon = null;
    public ArrayList<MSTVirtualBeacon> mstVirtualBeaconList = new ArrayList<>();

    private ArrayList<NotificationModel> notificationList = new ArrayList<>();
    PreferenceHelper preferenceHelper;

    private RecyclerView notificationListView;
    private NotificationBeaconListAdapter notificationBeaconListAdapter;
    private LinearLayoutManager linearLayoutManager = null;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //set up notitle
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        preferenceHelper = new PreferenceHelper(this);
        handler = new Handler();


        if(getIntent()!=null)
        {
            placeNameModel    = (PlaceNameModel)  getIntent().getSerializableExtra("placeNameModel");
        }

        notificationListView = (RecyclerView) findViewById(R.id.notificationListView);
        notificationBeaconListAdapter = new NotificationBeaconListAdapter(this, notificationList);
        linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setReverseLayout(true);
        notificationListView.setLayoutManager(linearLayoutManager);
        notificationListView.setHasFixedSize(true);
        notificationListView.setAdapter(notificationBeaconListAdapter);
        notificationBeaconListAdapter.notifyDataSetChanged();
        setListViewParams(1);

        loadFragment();

        if(placeNameModel!=null && !placeNameModel.getsHeaderName().equalsIgnoreCase("Demo")) {
            this.venueId = placeNameModel.getVenueID();
            this.venuePassword = placeNameModel.getVenuePassword();
            this.environment = placeNameModel.getEnv();
            this.hostUri = placeNameModel.getHost();
            this.name = placeNameModel.getsPlaceName();


            this.app = ((MainApplication) getApplication());
            this.app.setMainActivity(this);
            connectToMist();
        }

    }

    private void connectToMist() {
        MainApplication app = (MainApplication) this.getApplication();
        app.handleConnect(this.venueId, this.venuePassword, this.environment, this, this.hostUri);
    }


    private void loadFragment()
    {
        OrgFragment homeFragment = OrgFragment.newInstance(placeNameModel, mstVirtualBeaconList);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.contentFrame , homeFragment, sFragmentTag).commit();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
       /* if(placeNameModel!=null) {
            MainApplication app = (MainApplication) this.getApplication();
            app.handleDisconnect();
        }*/
    }


    @Override
    public void onBeaconDetected(MSTBeacon[] beaconArray, String region, Date dateUpdated) {
        System.out.println("Entappiainc: onBeaconDetected");
    }

    @Override
    public void onBeaconDetected(JSONArray jsonArray, Date date) {
        if(jsonArray != null) {
            Log.v(OrgActivity.class.getSimpleName(),"onBeaconDetected: jsonArray size" + jsonArray.length());
        }
    }

    @Override
    public void onBeaconListUpdated(HashMap hashMap, Date date) {
        System.out.println("Entappiainc: onBeaconListUpdated");
    }

    @Override
    public void onLocationUpdated(final LatLng location, MSTMap[] maps, SourceType locationSource, Date dateUpdated) {
        System.out.println("Entappiainc: onLocationUpdated");

    }

    @Override
    public void onRelativeLocationUpdated(MSTPoint relativeLocation, MSTMap[] maps, Date dateUpdated) {
        System.out.println("Entappiainc: onRelativeLocationUpdated " + relativeLocation.getX() + ", " + relativeLocation.getY());

        if(relativeLocation!=null && maps!=null) {
            boolean isNewMap = false;
            if (this.mstMap == null || !this.mstMap.getMapId().equals(maps[0].getMapId())) {
                mstMap = maps[0];
                isNewMap = true;
            }

            mstPoint = relativeLocation;
            updateRelativeLocation(isNewMap);
        }
    }

    /**
     * Returns updated pressure when available to the app. The pressure will be a double measured in millibars
     * @param pressure Updated pressure
     * @param dateUpdated Date when the pressure was updated
     */
    @Override
    public void onPressureUpdated(double pressure, Date dateUpdated){

    }
    @Override
    public void onZoneStatsUpdated(MSTZone[] zones, Date dateUpdated) {
        System.out.println("Entappiainc: onZoneStatsUpdated");
    }

    @Override
    public void onClientUpdated(MSTClient[] clients, MSTZone[] zones, Date dateUpdated) {
        System.out.println("Entappiainc: onClientUpdated");
    }

    @Override
    public void onAssetUpdated(MSTAsset[] assets, MSTZone[] zones, Date dateUpdated) {
        System.out.println("Entappiainc: onAssetUpdated");
    }

    @Override
    public void onMapUpdated(final MSTMap map, Date dateUpdated) {
        System.out.println("Entappiainc: onMapUpdated " + map);

        // Received map has changed, update the mstMap.
        this.mstMap = map;

        // Therefore update the map
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Fragment leftFragment = getSupportFragmentManager().findFragmentByTag(sFragmentTag);

                if (leftFragment instanceof FloorplanFragment){
                    FloorplanFragment mOrgFragment = (FloorplanFragment)leftFragment;
                    mOrgFragment.addIndoorMap(map);
                }
            }
        });
    }

    @Override
    public void onVirtualBeaconListUpdated(MSTVirtualBeacon[] virtualBeacons, Date dateUpdated) {
        System.out.println("Entappiainc: onVirtualBeaconListUpdated: " + virtualBeacons.toString());

        if(virtualBeacons!=null) {
            for(MSTVirtualBeacon mstVirtualBeacon : virtualBeacons)
            {
                if(mstVirtualBeacon!=null  )
                {
                    if(!Utility.isEmptyString(mstVirtualBeacon.getVbid()) && ! checkMSTVirtualBeacon(mstVirtualBeacon.getVbid(), mstVirtualBeaconList) )
                    {
                        mstVirtualBeaconList.add(mstVirtualBeacon);
                    }
                }
            }




        }
    }


    @Override
    public void onNotificationReceived(final Date dateReceived, final String message) {
        System.out.println("Entappiainc: onNotificationReceived");
        if (!Utility.isEmptyString(message)) {
            try {
                JSONObject notificationJSONObject = new JSONObject(message);

                String type = notificationJSONObject.getString("type");
                if (type.equalsIgnoreCase("zone-event-vb")) {

                    //title = "Vbeacon notification";
                    JSONObject messageObject = notificationJSONObject.optJSONObject("message");
                    System.out.println("Notification message: " + messageObject);
                    if (messageObject != null) {

                        String sName = "";
                        String deviceID = MistIDGenerator.getMistUUID(OrgActivity.this);
                        String sUserId = messageObject.optString("UserID");
                        // body = "You've seen " + messageObject.getString("Extra") + " and are moving " + messageObject.getString("direction") + "\nMajor: " + messageObject.get("vbMajor") + " , Minor: " + messageObject.get("vbMinor") + " , Proximity: " + messageObject.get("proximity");

                        if (deviceID != null && sUserId != null && sUserId.equals(deviceID))
                            sName = "You're ";

                        String vbID = messageObject.optString("vbID");
                        int listPosition = notificationListPosition(vbID);
                        String sBeaconBody = sName + "near " + messageObject.getString("Extra");
                        if (messageObject.getString("proximity").equals("near") || messageObject.getString("proximity").equals("immediate")) {

                            if (listPosition == -1 && !Utility.isEmptyString(messageObject.getString("Extra"))) {

                                Object[] objects = getVirtualBeaconUrl(vbID);

                                NotificationModel notificationModel = new NotificationModel();
                                notificationModel.setBodyMessage(sBeaconBody);
                                notificationModel.setNotificationID(vbID);
                                if (objects != null)
                                    notificationModel.setForwardUrl(objects[0].toString());
                                else
                                    notificationModel.setForwardUrl("");

                                if (objects != null && objects[1] != null && !Utility.isEmptyString(objects[1].toString())) {
                                    notificationModel.setBodyMessage(objects[1].toString());
                                } else
                                    notificationModel.setBodyMessage(sBeaconBody);

                                notificationModel.setBeaconNotification(true);

                                notificationList.add(notificationModel);
                                new Thread(new NotificationTask()).start();
                            }
                        } else {
                            if (listPosition != -1) {
                                notificationList.remove(listPosition);
                                new Thread(new NotificationTask()).start();
                            }
                        }
                    }

                } else if (type.equalsIgnoreCase("zones-events")) {
                    //title = "Zone notification";
                    JSONObject messageObject = notificationJSONObject.getJSONObject("message");
                    String sTrigger = messageObject.getString("Trigger");
                    String sZoneID = messageObject.getString("ZoneID");
                    int listPosition = notificationListPosition(sZoneID);
                    if (sTrigger.equalsIgnoreCase("in")) {
                        if (listPosition == -1 && !Utility.isEmptyString(messageObject.getString("Extra"))) {
                            String sZoneBody = "You are inside the " + messageObject.getString("Extra");
                            NotificationModel notificationModel = new NotificationModel();
                            notificationModel.setBodyMessage(sZoneBody);
                            notificationModel.setForwardUrl("");
                            notificationModel.setBeaconNotification(false);
                            notificationModel.setNotificationID(sZoneID);
                            notificationList.add(notificationModel);
                            new Thread(new NotificationTask()).start();
                        }
                    } else if (sTrigger.equalsIgnoreCase("out")) {
                        if (listPosition != -1) {
                            notificationList.remove(listPosition);
                            new Thread(new NotificationTask()).start();
                        }
                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onClientInformationUpdated(String clientName) {
        System.out.println("Entappiainc: onClientInformationUpdated "+clientName);
    }

    @Override
    public void onReceivedSecret(String orgName, String orgID, String sdkSecret, String error) {
        System.out.println("Entappiainc: onReceivedSecret");
    }

    @Override
    public void receivedLogMessageForCode(final String message, MSTCentralManagerStatusCode code) {
        if (code != (MSTCentralManagerStatusCode.MSTCentralManagerStatusCodeSentJSON) &&
                code != (MSTCentralManagerStatusCode.MSTCentralManagerStatusCodeReceivedLE)) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    System.out.println("receivedLogMessageForCode: " + message);
                    Toaster.toast("log:"+message);
                }
            });
        }
    }

    @Override
    public void receivedVerboseLogMessage(String message) {

    }

    @Override
    public void onMistErrorReceived(String s, Date date) {

    }


    @Override
    public void onMistRecommendedAction(String s) {

    }


    // get notification list postion by zone id
    private int notificationListPosition(String sZoneId) {
        for (int i = 0; i < notificationList.size(); i++) {
            NotificationModel notificationModel = notificationList.get(i);

            if (!Utility.isEmptyString(notificationModel.getNotificationID())
                    && notificationModel.getNotificationID().equals(sZoneId)) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public void performAdapterAction(String tagName, Object data) {
        if (tagName.equals("set_listview_height")) {
            int size = (int) data;
            setListViewParams(size);
        }
    }



    class NotificationTask implements Runnable {
        @Override
        public void run() {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            handler.post(new Runnable() {
                @Override
                public void run() {
                    int itemHeight = preferenceHelper.getIntValue("notification_listview_height");
                    setListViewParams(itemHeight > 0 ? itemHeight : 1);
                    if (notificationBeaconListAdapter != null)
                        notificationBeaconListAdapter.notifyDataSetChanged();

                }
            });
        }
    }

    private void setListViewParams(int size) {

        notificationListView.setVisibility(View.VISIBLE);
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) notificationListView.getLayoutParams();
        if (notificationList.size() > 5)
            params.height = size * 6;
        else
            params.height = size * notificationList.size();
        notificationListView.setLayoutParams(params);
    }

    public Object[] getVirtualBeaconUrl(String mstVirtualBeaconId) {
        if (!Utility.isEmptyString(mstVirtualBeaconId) && mstVirtualBeaconList.size() != 0) {
            for (final MSTVirtualBeacon mstVirtualBeacon : mstVirtualBeaconList) {
                if (!Utility.isEmpty(mstVirtualBeacon) &&
                        mstVirtualBeacon.getVbid().equals(mstVirtualBeaconId)) {
                    Object[] objects = new Object[2];
                    objects[0] = mstVirtualBeacon.getUrl();
                    objects[1] = mstVirtualBeacon.getMessage();
                    return objects;
                }
            }
        }
        return null;

    }

    private void updateRelativeLocation(final boolean isNewMap)
    {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                    Fragment fragment = getSupportFragmentManager().findFragmentByTag(sFragmentTag);
                    if (fragment instanceof FloorplanFragment){
                        FloorplanFragment mFloorplanFragment = (FloorplanFragment)fragment;

                        if (isNewMap || mFloorplanFragment.currentMap == null || (!mFloorplanFragment.addedMap && OrgActivity.this.mstMap != null)) {
                            // If the map hasn't been added and the mstMap has already been downloaded, add the map
                           if(isNewMap || mFloorplanFragment.currentMap == null )
                                mFloorplanFragment.addIndoorMap(OrgActivity.this.mstMap);
                            else
                                mFloorplanFragment.renderBluedot(mstPoint);
                        } else {
                            // If the map has been added, then render the bluedot
                            mFloorplanFragment.renderBluedot(mstPoint);
                        }
                    } else {
                        System.out.println("onRelativeLocationUpdated: Left fragment is not an instance of FloorplanFragment");
                    }
            }
        });
    }


    public boolean checkMSTVirtualBeacon(String mstVirtualBeaconId, ArrayList<MSTVirtualBeacon> mstVirtualBeaconList)
    {
        if(!Utility.isEmptyString(mstVirtualBeaconId)) {
            for (final MSTVirtualBeacon mstVirtualBeacon : mstVirtualBeaconList) {
                if (!Utility.isEmpty(mstVirtualBeacon)) {
                    if (!Utility.isEmptyString(mstVirtualBeacon.getVbid()) &&
                            mstVirtualBeacon.getVbid().contains(mstVirtualBeaconId)) {
                        return true;
                    }
                }
            }
        }

        return false;

    }

    @Override
    public void performFragmentActivityAction(String tagName, Object data) {
        if(tagName.equals("load_show_floor_fragment"))
        {
            loadShowFloorFragment(false);
        }else if(tagName.equals("load_show_vb_fragment"))
        {
            loadShowFloorFragment(true);
        }

    }

    @Override
    protected void onPause() {
        super.onPause();

        //TODO: Added for background mode
        if(this.app!=null) {
            app.setAppMode(new AppModeParams(AppMode.BACKGROUND,BatteryUsage.LOW_BATTERY_USAGE_LOW_ACCURACY,true,1d,5d));
            isAppInBackground = true; //Flag that app is in the background
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        //TODO: Added for background mode
        //Avoids the app startup calling this
        if (isAppInBackground && this.app!=null) {
            app.setAppMode(new AppModeParams(AppMode.FOREGROUND, BatteryUsage.HIGH_BATTERY_USAGE_HIGH_ACCURACY));
            isAppInBackground = false;
        }
    }

    private void loadShowFloorFragment(boolean isMSTVirtualBeaconShown)
    {
        FloorplanFragment floorplanFragment =  FloorplanFragment.newInstance(isMSTVirtualBeaconShown);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.contentFrame, floorplanFragment, sFragmentTag).commit();
    }
}
