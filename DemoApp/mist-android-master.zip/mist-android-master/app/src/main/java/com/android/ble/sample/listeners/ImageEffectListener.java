package com.android.ble.sample.listeners;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

/**
 * Created by Entappia.
 * Activity that list the activities
 * touch listener for dash board icons to highlight when click a icon.
 */
public class ImageEffectListener implements View.OnTouchListener {
    int colorValue = Color.TRANSPARENT;

    public ImageEffectListener(int color) {
        colorValue = color;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (v instanceof ImageView) {
            ImageView v1 = (ImageView) v;
            int maskId = event.getActionMasked();
            if (maskId == MotionEvent.ACTION_DOWN) {
                if (v1.getDrawable() != null) {
                    v1.getDrawable().setColorFilter(colorValue, PorterDuff.Mode.SRC_ATOP);
                    v1.invalidate();
                }
            } else if (maskId == MotionEvent.ACTION_CANCEL || maskId == MotionEvent.ACTION_UP) {
                if (v1.getDrawable() != null) {
                    v1.getDrawable().clearColorFilter();
                    v1.invalidate();
                }
            }
        }
        return false;
    }
}