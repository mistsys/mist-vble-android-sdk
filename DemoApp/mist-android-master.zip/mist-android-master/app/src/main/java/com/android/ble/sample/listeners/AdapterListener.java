package com.android.ble.sample.listeners;

/**
 * Created by Entappiainc on 21-04-2016.
 */
public interface AdapterListener {
    public void performAdapterAction(String tagName, Object data);
}
