package com.android.ble.sample.listeners;

/**
 * Created by Entappiainc on 08-03-2016.
 */
public interface DialogListener {
    public void performDialogAction(String tagName, Object data);
}
