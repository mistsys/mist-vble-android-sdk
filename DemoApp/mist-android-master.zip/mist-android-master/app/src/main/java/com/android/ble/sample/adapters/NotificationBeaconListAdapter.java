package com.android.ble.sample.adapters;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.ble.sample.R;
import com.android.ble.sample.helper.PreferenceHelper;
import com.android.ble.sample.listeners.AdapterListener;
import com.android.ble.sample.listeners.ImageEffectListener;
import com.android.ble.sample.model.NotificationModel;

import java.util.ArrayList;

/**
 * Created by Entappia on 21-04-2016.
 */
public class NotificationBeaconListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder >
{

    ArrayList<NotificationModel> beaconNameList = new ArrayList<>();

    Context mContext;
    LayoutInflater inflater = null;
    AdapterListener adapterListener;
    int itemHeight = 0;
    PreferenceHelper preferenceHelper;

    public NotificationBeaconListAdapter(Context mContext, ArrayList<NotificationModel> beaconNameList) {
        this.mContext = mContext;
        adapterListener = (AdapterListener) mContext;
        this.beaconNameList = beaconNameList;
        preferenceHelper = new PreferenceHelper(mContext);
        inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }



    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.nearbeacons_list_item, null);
        RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        v.setLayoutParams(lp);
        BeaconListHeaderHolder mh = new BeaconListHeaderHolder(v);
        return mh;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        final BeaconListHeaderHolder viewHolder = (BeaconListHeaderHolder) holder ;

        final NotificationModel notificationModel = beaconNameList.get(position);
        viewHolder.beaconNameTextView.setText(notificationModel.getBodyMessage());

        if(notificationModel.isBeaconNotification())
            viewHolder.notificationContentLayout.setBackgroundResource(R.drawable.list_notification_beacon_bg);
        else
            viewHolder.notificationContentLayout.setBackgroundResource(R.drawable.list_notification_zone_bg);

        viewHolder.deleteBeaconImaheView.setOnTouchListener(new ImageEffectListener(Color.parseColor("#007aff")));
        itemHeight = preferenceHelper.getIntValue("notification_listview_height" );



        if (itemHeight == 0) {
            ViewTreeObserver vto = viewHolder.contentLayout.getViewTreeObserver();
            vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    viewHolder.contentLayout.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                    itemHeight = viewHolder.contentLayout.getMeasuredHeight();
                    preferenceHelper.saveIntValue("notification_listview_height", itemHeight);
                    adapterListener.performAdapterAction("set_listview_height", itemHeight);
                }
            });
        }else
            adapterListener.performAdapterAction("set_listview_height", itemHeight);

        viewHolder.deleteBeaconImaheView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(beaconNameList.size()>position)
                    beaconNameList.remove(position);
                notifyDataSetChanged();
            }
        });


    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return beaconNameList.size();
    }

    public static class BeaconListHeaderHolder  extends RecyclerView.ViewHolder {
        LinearLayout contentLayout, notificationContentLayout;
        TextView beaconNameTextView;
        ImageView deleteBeaconImaheView ;

        public BeaconListHeaderHolder(View view) {
            super(view);
            this.contentLayout = (LinearLayout) view.findViewById(R.id.contentLayout);
            this.notificationContentLayout = (LinearLayout) view.findViewById(R.id.notificationContentLayout);
            this.beaconNameTextView = (TextView) view.findViewById(R.id.beaconNameTextView);
            this.deleteBeaconImaheView = (ImageView)view.findViewById(R.id.deleteImageView);
        }
    }

}
