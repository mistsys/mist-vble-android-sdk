package com.android.ble.sample.listeners;

/**
 * Created by Entappiainc on 30-08-2016.
 */
public interface FragmentActivityListener {
    public void performFragmentActivityAction(String tagName, Object data);
}
