package com.android.ble.sample.activity;

import com.journeyapps.barcodescanner.CaptureActivity;

/**
 * Created by Entappiainc on 30-08-2016.
 */
public class AnyOrientationCaptureActivity extends CaptureActivity {
}
