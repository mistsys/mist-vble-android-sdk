package com.android.ble.sample.listeners;

/**
 * Created by Entappiainc on 5/12/16.
 */
public interface Callback {
    public void onComplete();
}
